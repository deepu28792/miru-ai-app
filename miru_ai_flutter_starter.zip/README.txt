
Miru AI - Flutter Starter App

This is a starter Flutter project for a Text/Image to AI Video generator.

How to build APK:

1. Install Flutter
2. Run: flutter pub get
3. Run: flutter build apk

Integrate APIs like:
- Runway ML
- Pika Labs
- Stability AI

Add HTTP requests inside the generateVideo() function.


import 'package:flutter/material.dart';

void main() {
  runApp(MiruAIApp());
}

class MiruAIApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Miru AI',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController promptController = TextEditingController();

  void generateVideo() {
    String prompt = promptController.text;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Video Generation"),
        content: Text(
            "This is where the API call to Runway/Pika would happen using the prompt: \n\n$prompt"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK"),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Miru AI - Text/Image to Video")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: promptController,
              maxLines: 4,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                hintText: "Enter text prompt for AI video",
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: generateVideo,
              child: Text("Generate AI Video"),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {},
              child: Text("Upload Image for Talking Video"),
            ),
            SizedBox(height: 20),
            Text("Premium AI video APIs can be integrated here.")
          ],
        ),
      ),
    );
  }
}
